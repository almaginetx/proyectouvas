<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'wordpress' );

/** MySQL database password */
define( 'DB_PASSWORD', '27a26fa2beadae952e94a9e2f02714c5eab8fe256766b14f' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '(2wDy,;f/u@|U?kX0PGO$T[ ?<8G0^?BB)(L[e;WH<MI.f{No**0;fp0!/!K`~j;' );
define( 'SECURE_AUTH_KEY',  '`X&>g:$_)=Bq.mTJJ@}Mxm,d3)q18(W&pN*tf!a[ T+&5<=V{J4mFy{[ O2Rd{~:' );
define( 'LOGGED_IN_KEY',    'Cljb>2UgxsNNv4PJ6(O^nC6%](bk5xAY3ex[e%UT2pvL3%tMK*Kk+w=GEBa0iQxl' );
define( 'NONCE_KEY',        '5$}=8*([2J$9X?N6@sZi[a|3*|M>/&l?66(wd3c>`F+>N2:v)H{O;G.(1g3a^|)I' );
define( 'AUTH_SALT',        'am3!w$nq;5bcTkmZ;R+fQeI)RE1~egcUa N6<bDQ}PeFF6r%QA+M}5i2{4:8D}*?' );
define( 'SECURE_AUTH_SALT', ';CmP?|M{GbMB}tCc8,CKbX#OwXpU>!4t~:3hX]2%iFK!0s>viV_Y,n9;WwAp*M2u' );
define( 'LOGGED_IN_SALT',   '` E,.!8TTln+80L-Ny4}HWd%3tVz9y=1|SEK#Z:T:)(I%_n<]8qN;*:wU;3(;T P' );
define( 'NONCE_SALT',       'W}D46-$]1^*l#]#DM{:/@&Vd1W6?JU=h2 $oRJKO8n#!EfB%ifIL$9Bi6g-vCawZ' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
